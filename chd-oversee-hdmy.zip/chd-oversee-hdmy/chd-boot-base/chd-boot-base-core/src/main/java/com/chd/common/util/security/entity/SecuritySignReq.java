package com.chd.common.util.security.entity;

import lombok.Data;

/**
 * @Description: SecuritySignReq
 * 
 */
@Data
public class SecuritySignReq {
    private String data;
    private String prikey;
}
