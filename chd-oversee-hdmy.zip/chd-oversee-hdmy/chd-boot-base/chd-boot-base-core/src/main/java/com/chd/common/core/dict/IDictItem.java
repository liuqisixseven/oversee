package com.chd.common.core.dict;

public interface IDictItem {

    public String getText();
    /**
     * 特殊用途： vue3 Select组件
     */
    public String getValue();
}
