package com.chd.config.vo;

/**
 * @Description: TODO
 * @author: scott
 * @date: 2022年01月21日 14:23
 */
public class Shiro {
    private String excludeUrls = "";

    public String getExcludeUrls() {
        return excludeUrls;
    }

    public void setExcludeUrls(String excludeUrls) {
        this.excludeUrls = excludeUrls;
    }
}
