//package com.chd.common.util.superSearch;
//
//import lombok.Data;
//
///**
// * @Description: QueryRuleVo
// * 
// */
//@Data
//public class QueryRuleVo {
//
//	private String field;
//	private String rule;
//	private String val;
//}
