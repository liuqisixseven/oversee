package com.chd.common.exception;

public interface ExceptionCode {

    Integer getCode();
    String  getMessage();
}
