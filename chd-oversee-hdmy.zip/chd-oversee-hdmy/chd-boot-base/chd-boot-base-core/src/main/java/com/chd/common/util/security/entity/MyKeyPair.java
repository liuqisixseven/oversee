package com.chd.common.util.security.entity;

import lombok.Data;

/**
 * @Description: MyKeyPair
 * 
 */
@Data
public class MyKeyPair {
    private String priKey;
    private String pubKey;
}
