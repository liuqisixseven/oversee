package com.chd.common.system.base.service;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Description: Service基类
 * @Author: dangzhenghui@163.com
 * @Date: 2019-4-21 8:13
 * @Version: 1.0
 */
public interface JeecgService<T> extends IService<T> {
}
