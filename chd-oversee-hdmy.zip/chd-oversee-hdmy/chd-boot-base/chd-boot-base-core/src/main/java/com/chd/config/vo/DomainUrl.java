package com.chd.config.vo;

import lombok.Data;

/**
 * @Author taoYan
 * @Date 2022/7/5 21:16
 **/
@Data
public class DomainUrl {

    private String pc;

    private String app;
}
