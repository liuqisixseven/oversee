package com.chd.modules.oversee.issue.mapper;

import com.chd.modules.oversee.issue.entity.SpecificIssues;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Description: specific_issues
 * @Author: jeecg-boot
 * @Date:   2022-08-03
 * @Version: V1.0
 */
public interface SpecificIssuesMapper extends BaseMapper<SpecificIssues> {

}
