package com.chd.modules.oversee.issue.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chd.modules.oversee.issue.entity.KafkaIssuesSendRecording;

/**
 * @Description: recover_funds
 * @Author: jeecg-boot
 * @Date:   2022-10-05
 * @Version: V1.0
 */
public interface KafkaIssuesSendRecordingMapper extends BaseMapper<KafkaIssuesSendRecording> {



}
