package com.chd.modules.oversee.hdmy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.chd.modules.oversee.hdmy.entity.MyUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Description: my_user
 * @Author: jeecg-boot
 * @Date:   2022-08-08
 * @Version: V1.0
 */
public interface MyUserMapper extends BaseMapper<MyUser> {

}
