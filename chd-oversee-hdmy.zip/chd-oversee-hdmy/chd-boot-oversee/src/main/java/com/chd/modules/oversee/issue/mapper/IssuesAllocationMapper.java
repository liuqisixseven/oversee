package com.chd.modules.oversee.issue.mapper;

import com.chd.modules.oversee.issue.entity.IssuesAllocation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Description: issues_allocation
 * @Author: jeecg-boot
 * @Date:   2022-08-03
 * @Version: V1.0
 */
public interface IssuesAllocationMapper extends BaseMapper<IssuesAllocation> {

}
