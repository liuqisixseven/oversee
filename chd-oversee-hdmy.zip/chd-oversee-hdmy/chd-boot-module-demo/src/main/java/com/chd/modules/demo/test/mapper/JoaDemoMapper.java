package com.chd.modules.demo.test.mapper;

import com.chd.modules.demo.test.entity.JoaDemo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Description: 流程测试
 * 
 * @Date:   2019-05-14
 * @Version: V1.0
 */
public interface JoaDemoMapper extends BaseMapper<JoaDemo> {

}
